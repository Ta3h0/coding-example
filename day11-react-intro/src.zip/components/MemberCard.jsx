import titleImg from "../img/initial_img.jpg";

function MemberCard(props) {
    return (
        <div className="member-card">
            <span className="member-card__chip">{props.chip}</span>
            <div className="member-card__title">
                <img src={titleImg} alt="이니셜 이미지" className="member-card__img" />
                <div>
                    <h3 className="member-card__name">{props.name}</h3>
                    <span className="member-card__role">{props.role}</span>
                </div>
            </div>
            <p className="member-card__content">{props.desc}</p>
            <div className="member-card__tag__list">
                <span className="member-card__tag">{props.tag[0]}</span>
                <span className="member-card__tag">{props.tag[1]}</span>
            </div>
        </div>
    );
}



export default MemberCard;